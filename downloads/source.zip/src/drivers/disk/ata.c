#include "ata.h"

void ata_wait() {
    for (int i = 0; i < 100000; i++) {
        if (!(inb(ATA_STATUS) & BSY) && (inb(ATA_STATUS) & DRQ))
            return;
    }
}

void ata_read_sector(uint32_t lba, uint8_t* buffer) {
    outb(ATA_DRIVE, 0xE0 | ((lba >> 24) & 0x0F)); // master drive + LBA high nibble
    outb(ATA_SECTOR_CNT, 1);                     // read 1 sector
    outb(ATA_LBA_LO,  (uint8_t)(lba & 0xFF));
    outb(ATA_LBA_MID, (uint8_t)((lba >> 8) & 0xFF));
    outb(ATA_LBA_HI,  (uint8_t)((lba >> 16) & 0xFF));
    outb(ATA_STATUS, ATA_CMD_READ);

    ata_wait();

    // read 512 bytes (256 words)
    for (int i = 0; i < 256; ++i) {
        uint16_t data = inw(ATA_PRIMARY_IO);
        buffer[i * 2]     = data & 0xFF;
        buffer[i * 2 + 1] = (data >> 8) & 0xFF;
    }
}

void ata_write_sector(uint32_t lba, const uint8_t* buffer) {
    outb(ATA_DRIVE, 0xE0 | ((lba >> 24) & 0x0F));
    outb(ATA_SECTOR_CNT, 1);
    outb(ATA_LBA_LO,  (uint8_t)(lba & 0xFF));
    outb(ATA_LBA_MID, (uint8_t)((lba >> 8) & 0xFF));
    outb(ATA_LBA_HI,  (uint8_t)((lba >> 16) & 0xFF));
    outb(ATA_STATUS, ATA_CMD_WRITE);

    ata_wait();

    for (int i = 0; i < 256; ++i) {
        uint16_t data = buffer[i * 2] | (buffer[i * 2 + 1] << 8);
        outw(ATA_PRIMARY_IO, data);
    }

    outb(ATA_STATUS, 0xE7);

    ata_wait();
}

void ata_write_sectors(uint32_t start_lba, const uint8_t* data, uint32_t sector_count) {
    for (uint32_t i = 0; i < sector_count; ++i) {
        uint32_t lba = start_lba + i;
        const uint8_t* sector_data = data + (i * 512);

        outb(ATA_DRIVE, 0xE0 | ((lba >> 24) & 0x0F));
        outb(ATA_SECTOR_CNT, 1); // always 1 per iteration
        outb(ATA_LBA_LO,  (uint8_t)(lba & 0xFF));
        outb(ATA_LBA_MID, (uint8_t)((lba >> 8) & 0xFF));
        outb(ATA_LBA_HI,  (uint8_t)((lba >> 16) & 0xFF));
        outb(ATA_STATUS, ATA_CMD_WRITE);

        ata_wait();

        for (int j = 0; j < 256; ++j) {
            uint16_t word = sector_data[j * 2] | (sector_data[j * 2 + 1] << 8);
            outw(ATA_PRIMARY_IO, word);
        }

        outb(ATA_STATUS, 0xE7);
        ata_wait();
    }
}

void ata_read_sectors(uint32_t start_lba, uint8_t* buffer, uint32_t sector_count) {
    for (uint32_t i = 0; i < sector_count; ++i) {
        uint32_t lba = start_lba + i;
        uint8_t* sector_buffer = buffer + (i * 512);

        outb(ATA_DRIVE, 0xE0 | ((lba >> 24) & 0x0F));
        outb(ATA_SECTOR_CNT, 1);
        outb(ATA_LBA_LO,  (uint8_t)(lba & 0xFF));
        outb(ATA_LBA_MID, (uint8_t)((lba >> 8) & 0xFF));
        outb(ATA_LBA_HI,  (uint8_t)((lba >> 16) & 0xFF));
        outb(ATA_STATUS, ATA_CMD_READ); // send read command

        ata_wait();

        for (int j = 0; j < 256; ++j) {
            uint16_t word = inw(ATA_PRIMARY_IO);
            sector_buffer[j * 2]     = word & 0xFF;
            sector_buffer[j * 2 + 1] = (word >> 8) & 0xFF;
        }
    }
}