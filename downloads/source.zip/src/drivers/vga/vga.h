#ifndef VGA_H
#define VGA_H

#include <stdint.h>
#include "../../kerneldef.h"

void draw_pixel(int x, int y, uint8_t color);
void clear_screen();
void draw_char(int x, int y, char c, uint8_t color);
void print(const char* str, int x, int y);
void print_uint8(uint8_t num, int row, int col);
void fill_rect(int x, int y, int width, int height, uint8_t color);
void set_cursor_pos(int x, int y);
void print_auto(const char* str);
void set_mode12h_palette();
void print_bg(const char* str, int x, int y, uint8_t bg);

#endif