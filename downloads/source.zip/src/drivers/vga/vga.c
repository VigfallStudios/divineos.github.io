#include "vga.h"

static const uint8_t font8x8_basic[128][8] = {
    ['A'] = { 0x18, 0x24, 0x42, 0x7E, 0x42, 0x42, 0x42, 0x00 },
    ['B'] = { 0x7C, 0x42, 0x42, 0x7C, 0x42, 0x42, 0x7C, 0x00 },
    ['C'] = { 0x3C, 0x42, 0x40, 0x40, 0x40, 0x42, 0x3C, 0x00 },
    ['D'] = { 0x78, 0x44, 0x42, 0x42, 0x42, 0x44, 0x78, 0x00 },
    ['E'] = { 0x7E, 0x40, 0x40, 0x7C, 0x40, 0x40, 0x7E, 0x00 },
    ['F'] = { 0x7E, 0x40, 0x40, 0x7C, 0x40, 0x40, 0x40, 0x00 },
    ['G'] = { 0x3C, 0x42, 0x40, 0x4E, 0x42, 0x42, 0x3C, 0x00 },
    ['H'] = { 0x42, 0x42, 0x42, 0x7E, 0x42, 0x42, 0x42, 0x00 },
    ['I'] = { 0x3C, 0x18, 0x18, 0x18, 0x18, 0x18, 0x3C, 0x00 },
    ['J'] = { 0x1E, 0x04, 0x04, 0x04, 0x44, 0x44, 0x38, 0x00 },
    ['K'] = { 0x42, 0x44, 0x48, 0x70, 0x48, 0x44, 0x42, 0x00 },
    ['L'] = { 0x40, 0x40, 0x40, 0x40, 0x40, 0x40, 0x7E, 0x00 },
    ['M'] = { 0x42, 0x66, 0x5A, 0x5A, 0x42, 0x42, 0x42, 0x00 },
    ['N'] = { 0x42, 0x62, 0x52, 0x4A, 0x46, 0x42, 0x42, 0x00 },
    ['O'] = { 0x3C, 0x42, 0x42, 0x42, 0x42, 0x42, 0x3C, 0x00 },
    ['P'] = { 0x7C, 0x42, 0x42, 0x7C, 0x40, 0x40, 0x40, 0x00 },
    ['Q'] = { 0x3C, 0x42, 0x42, 0x42, 0x52, 0x4C, 0x3A, 0x00 },
    ['R'] = { 0x7C, 0x42, 0x42, 0x7C, 0x48, 0x44, 0x42, 0x00 },
    ['S'] = { 0x3C, 0x42, 0x40, 0x3C, 0x02, 0x42, 0x3C, 0x00 },
    ['T'] = { 0x7E, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x00 },
    ['U'] = { 0x42, 0x42, 0x42, 0x42, 0x42, 0x42, 0x3C, 0x00 },
    ['V'] = { 0x42, 0x42, 0x42, 0x42, 0x24, 0x24, 0x18, 0x00 },
    ['W'] = { 0x42, 0x42, 0x42, 0x5A, 0x5A, 0x66, 0x42, 0x00 },
    ['X'] = { 0x42, 0x42, 0x24, 0x18, 0x24, 0x42, 0x42, 0x00 },
    ['Y'] = { 0x42, 0x42, 0x24, 0x18, 0x18, 0x18, 0x18, 0x00 },
    ['Z'] = { 0x7E, 0x02, 0x04, 0x18, 0x20, 0x40, 0x7E, 0x00 },

    [' '] = { 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00 },
    ['.'] = { 0x00,0x00,0x00,0x00,0x00,0x18,0x18,0x00 },
    [','] = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x18, 0x10, 0x20 },
    [';'] = { 0x00, 0x18, 0x18, 0x00, 0x00, 0x18, 0x10, 0x20 },
    [':'] = { 0x00, 0x18, 0x18, 0x00, 0x00, 0x18, 0x18, 0x00 },
    ['<'] = { 0x00, 0x0C, 0x10, 0x60, 0x10, 0x0C, 0x00, 0x00 },
    ['>'] = { 0x00, 0x60, 0x10, 0x0C, 0x10, 0x60, 0x00, 0x00 },
    ['('] = { 0x0C, 0x10, 0x20, 0x20, 0x20, 0x10, 0x0C, 0x00 },
    [')'] = { 0x30, 0x08, 0x04, 0x04, 0x04, 0x08, 0x30, 0x00 },
    ['\''] = { 0x10, 0x10, 0x10, 0x20, 0x00, 0x00, 0x00, 0x00 },
};

void set_vga_dac_color(uint8_t index, uint8_t r, uint8_t g, uint8_t b) {
    outb(0x3C8, index); // set write index
    outb(0x3C9, r);
    outb(0x3C9, g);
    outb(0x3C9, b);
}

void set_attribute_entry(uint8_t index, uint8_t palette_index) {
    inb(0x3DA); // reset flip-flop
    outb(0x3C0, index);
    outb(0x3C0, palette_index);
}

void set_mode12h_palette()
{
    set_vga_dac_color(0,  0,  0,  0);    // black
    set_vga_dac_color(1, 42,  0,  0);    // dark red
    set_vga_dac_color(2,  0, 42,  0);    // dark green
    set_vga_dac_color(3, 42, 21,  0);    // brown
    set_vga_dac_color(4,  0,  0, 42);    // dark blue
    set_vga_dac_color(5, 42,  0, 42);    // purple
    set_vga_dac_color(6,  0, 42, 42);    // cyan
    set_vga_dac_color(7, 42, 42, 42);    // light gray
    set_vga_dac_color(8, 21, 21, 21);    // dark gray
    set_vga_dac_color(9, 63, 21, 21);    // red
    set_vga_dac_color(10, 21, 63, 21);   // green
    set_vga_dac_color(11, 63, 63, 21);   // yellow
    set_vga_dac_color(12, 21, 21, 63);   // blue
    set_vga_dac_color(13, 63, 21, 63);   // magenta
    set_vga_dac_color(14, 21, 63, 63);   // cyan
    set_vga_dac_color(15, 63, 63, 63);   // white

    // Map logical colors 0–15 to palette indices 0–15
    for (int i = 0; i < 16; i++) {
        set_attribute_entry(i, i);
    }

    inb(0x3DA);
    outb(0x3C0, 0x20); // Enable video output
}

uint8_t get_plane_mask() {
    outb(0x3C4, 0x02);
    return inb(0x3C5);
}

void set_plane_mask(uint8_t mask) {
    outb(0x3C4, 0x02);
    outb(0x3C5, mask);
}

void select_plane(int plane) {
    outb(0x3C4, 0x02);         // Sequencer index: Map Mask
    outb(0x3C5, 1 << plane);   // Enable write to plane
}

void clear_screen() {
    uint8_t* vram = (uint8_t*)0xA0000;

    for (int plane = 0; plane < 4; ++plane) {
        select_plane(plane);

        // Fill entire 64KB VGA plane with 0s
        for (uint32_t i = 0; i < 64000; ++i) {
            vram[i] = 0x00;
        }
    }
}

void draw_pixel(int x, int y, uint8_t color) {
    uint8_t bit = 0x80 >> (x % 8);                 // bitmask within byte
    uint16_t offset = (y * 80) + (x / 8);          // byte offset in memory
    volatile uint8_t* vram = (uint8_t*)0xA0000;

    for (int plane = 0; plane < 4; ++plane) {
        select_plane(plane);
        uint8_t* byte = (uint8_t*)(vram + offset);

        if (color & (1 << plane))
            *byte |= bit;
        else
            *byte &= ~bit;
    }
}

void draw_char(int x, int y, char c, uint8_t color) {
    if (c < 0 || c >= 128) return;
    if (x % 8 != 0) return; // Byte-aligned only

    uint8_t* vram = (uint8_t*)0xA0000;
    uint8_t original_mask = get_plane_mask(); // Save mask

    for (int plane = 0; plane < 4; ++plane) {
        select_plane(plane);

        uint8_t fg_bit = (color >> plane) & 1;
        uint8_t bg_bit = (DEF_BG >> plane) & 1;

        for (int row = 0; row < 8; row++) {
            uint8_t bits = font8x8_basic[(int)c][row];
            uint8_t out_byte = 0;

            for (int col = 0; col < 8; ++col) {
                int mask = 1 << (7 - col);
                if (bits & mask)
                    out_byte |= (fg_bit << (7 - col));
                else
                    out_byte |= (bg_bit << (7 - col));
            }

            int offset = (y + row) * 80 + (x / 8);
            vram[offset] = out_byte;
        }
    }

    set_plane_mask(original_mask); // Restore
}

void draw_char_bg(int x, int y, char c, uint8_t color, uint8_t bg) {
    if (c < 0 || c >= 128) return;
    if (x % 8 != 0) return; // Byte-aligned only

    uint8_t* vram = (uint8_t*)0xA0000;
    uint8_t original_mask = get_plane_mask(); // Save mask

    for (int plane = 0; plane < 4; ++plane) {
        select_plane(plane);

        uint8_t fg_bit = (color >> plane) & 1;
        uint8_t bg_bit = (bg >> plane) & 1;

        for (int row = 0; row < 8; row++) {
            uint8_t bits = font8x8_basic[(int)c][row];
            uint8_t out_byte = 0;

            for (int col = 0; col < 8; ++col) {
                int mask = 1 << (7 - col);
                if (bits & mask)
                    out_byte |= (fg_bit << (7 - col));
                else
                    out_byte |= (bg_bit << (7 - col));
            }

            int offset = (y + row) * 80 + (x / 8);
            vram[offset] = out_byte;
        }
    }

    set_plane_mask(original_mask); // Restore
}

void print(const char* str, int x, int y) {
    int orig_x = x;
    while (*str) {
        if (*str == '\n') {
            y += 8;
            x = orig_x;
        } else {
            draw_char(x, y, *str, DEF_FG);
            x += 8;
        }
        str++;
    }
}

void print_bg(const char* str, int x, int y, uint8_t bg) {
    int orig_x = x;
    while (*str) {
        if (*str == '\n') {
            y += 8;
            x = orig_x;
        } else {
            draw_char_bg(x, y, *str, DEF_FG, bg);
            x += 8;
        }
        str++;
    }
}

void print_uint8(uint8_t num, int row, int col)
{
    char buffer[4];
    int i = 0;

    if (num == 0) {
        draw_char(row, col, '0', DEF_FG);
        return;
    }

    while (num > 0) {
        buffer[i++] = '0' + (num % 10);
        num /= 10;
    }

    for (int j = i - 1; j >= 0; --j) {
        draw_char(row++, col, buffer[j], 15);
    }
}

void draw_color_bars() {
    int width = 640 / 16;

    for (int i = 0; i < 16; ++i) {
        for (int y = 0; y < 480; ++y) {
            for (int x = i * width; x < (i + 1) * width; ++x) {
                draw_pixel(x, y, i);
            }
        }
    }
}

void fill_rect(int x, int y, int width, int height, uint8_t color) {
    if (x % 8 != 0 || width % 8 != 0) return;  // Must be byte-aligned!

    uint8_t* vram = (uint8_t*)0xA0000;
    uint8_t original_mask = get_plane_mask(); // 👈 Save

    for (int plane = 0; plane < 4; ++plane) {
        select_plane(plane);

        uint8_t plane_mask = (color >> plane) & 1 ? 0xFF : 0x00;

        for (int dy = 0; dy < height; ++dy) {
            int offset = (y + dy) * 80 + (x / 8);
            for (int dx = 0; dx < width / 8; ++dx) {
                vram[offset + dx] = plane_mask;
            }
        }
    }

    set_plane_mask(original_mask); // 👈 Restore
}

int cursor_x = 0;
int cursor_y = 0;

#define CHAR_WIDTH 8
#define CHAR_HEIGHT 8
#define SCREEN_WIDTH 640
#define SCREEN_HEIGHT 480

void set_cursor_pos(int x, int y)
{
    cursor_x = x;
    cursor_y = y;
}

void print_auto(const char* str) {
    serial_write_string("Noo!\n");
    while (*str) {
        if (*str == '\n') {
            cursor_x = 0;
            cursor_y += CHAR_HEIGHT;

            // Scroll if we hit bottom
            if (cursor_y >= SCREEN_HEIGHT) {
                cursor_y = 0;
                clear_screen();
            }
        } else {
            draw_char(cursor_x, cursor_y, *str, 15);
            cursor_x += CHAR_WIDTH;

            // Wrap text if we reach right edge
            if (cursor_x >= SCREEN_WIDTH) {
                cursor_x = 0;
                cursor_y += CHAR_HEIGHT;

                if (cursor_y >= SCREEN_HEIGHT) {
                    cursor_y = 0;
                    clear_screen();
                }
            }
        }
        str++;
    }

    serial_write_string(str);
}