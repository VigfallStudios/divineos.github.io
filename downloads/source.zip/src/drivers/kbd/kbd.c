#include "kbd.h"

int keyboard_has_data()
{
    return inb(KBD_STATUS) & 1;
}

uint8_t keyboard_read_scan_code()
{
    while (!keyboard_has_data());

    return inb(KBD_DATA);
}

char scancode_to_ascii(uint8_t scancode)
{
    switch (scancode)
    {
        case 2:  return '1';
        case 3:  return '2';
        case 4:  return '3';
        case 5:  return '4';
        case 6:  return '5';
        case 7:  return '6';
        case 8:  return '7';
        case 9:  return '8';
        case 10: return '9';
        case 11: return '0';
        case 12: return '-';
        case 13: return '=';
        case 14: return '\b';  // Backspace
        case 15: return '\t';  // Tab
        case 16: return 'Q';
        case 17: return 'W';
        case 18: return 'E';
        case 19: return 'R';
        case 20: return 'T';
        case 21: return 'Y';
        case 22: return 'U';
        case 23: return 'I';
        case 24: return 'O';
        case 25: return 'P';
        case 26: return '[';
        case 27: return ']';
        case 28: return '\n';  // Enter
        case 30: return 'A';
        case 31: return 'S';
        case 32: return 'D';
        case 33: return 'F';
        case 34: return 'G';
        case 35: return 'H';
        case 36: return 'J';
        case 37: return 'K';
        case 38: return 'L';
        case 39: return ';';
        case 40: return '\'';
        case 41: return '`';
        case 43: return '\\';
        case 44: return 'Z';
        case 45: return 'X';
        case 46: return 'C';
        case 47: return 'V';
        case 48: return 'B';
        case 49: return 'N';
        case 50: return 'M';
        case 51: return ',';
        case 52: return '.';
        case 53: return '/';
        case 57: return ' ';   // Space bar
        default: return 0;     // Unknown or unhandled key
    }
}

void mouse_wait_write() {
    while ((inb(0x64) & 0x02) != 0);
}

void mouse_wait_read() {
    while ((inb(0x64) & 0x01) == 0);
}

void mouse_write(uint8_t value) {
    mouse_wait_write();
    outb(0x64, 0xD4); // Tell the PS/2 controller we want to talk to the mouse
    mouse_wait_write();
    outb(0x60, value);
}

uint8_t mouse_read() {
    mouse_wait_read();
    return inb(0x60);
}

void mouse_init() {
    mouse_write(0xF4); // Enable mouse
    (void)mouse_read(); // ACK (0xFA)
}

int xP = 0;
int yP = 28;

#define MAX_INPUT_LEN 128
char input_buffer[MAX_INPUT_LEN];
int input_len = 0;

const char *openers[] = {
    "REJOICE", "HEARKEN", "BEHOLD", "GIVE PRAISE", "LET HIM WHO HAS EARS HEAR",
    "THUS SAITH THE LORD", "O YE OF LITTLE FAITH", "SING, O DAUGHTER OF ZION",
    "LIFT UP THINE EYES", "BLESSED IS HE THAT COMETH"
};

const char *subjects[] = {
    "THE LAMB", "THE MOUNTAIN", "THE WILDERNESS", "THE PROPHET",
    "THE ANGEL", "THE WORD", "THE TRUMPET", "THE STONE",
    "THE CROWN", "THE BRIDE", "THE FOUNTAIN", "THE LIGHT"
};

const char *actions[] = {
    "CRIED OUT", "WAS LIFTED UP", "WAS MADE FLESH", "SHALL BE BROKEN",
    "IS RISEN", "POURED FORTH", "DID FALL", "WANDERED", "WAS HIDDEN", "SHONE BRIGHT"
};

const char *closings[] = {
    "AND THE PEOPLE MARVELED", "AND THERE WAS GREAT JOY", "AND THEY WERE AFRAID",
    "AND THE EARTH TREMBLED", "AND THE HEAVENS OPENED", "AND IT WAS SO",
    "FOR THE TIME IS AT HAND", "AND PEACE WAS UPON THEM", "AND THE ANGELS SANG"
};

uint8_t rand()
{
    uint8_t raw_seconds = cmos_read(0x00);
    uint8_t seconds = bcd_to_bin(raw_seconds);

    return seconds;
}

// Very basic LCG PRNG
static uint32_t prng_state = 0;

void wait_for_entropy_and_seed() {
    uint32_t entropy = 0;
    while (!keyboard_has_data()) {
        entropy++;
    }
    seed_rand_with(entropy);
}

void seed_rand_with(uint32_t seed) {
    prng_state = seed;
}

uint32_t rand32()
{
    prng_state = prng_state * 1664525 + 1013904223;
    return prng_state;
}

#define GODWORD_MAX 512 // Adjust as needed

char *GOD_WORDS[] = {
    "African", "Angel", "BBC", "BRB", "Bam", "Boo", "Burp", "CIA",
    "California", "Catastrophic Success", "China", "Church", "Cosmos", "Dad",
    "Dudly Doright", "FBI", "GarryKasparov", "Ghost", "Give me praise", "God",
    "God is not mocked", "God smack", "Greece", "Greek to me", "Han shot first",
    "rufus!", "Hasta", "Heaven", "Hicc up", "HolySpirit", "I'll ask nicely",
    "I'll be back", "I'll get right on it", "I'll let you know", "I'll think about it",
    "I'm God and you're not", "I'm God who the hell are you", "I'm beginning to wonder",
    "I'm bored", "I'm busy", "I'm done", "I'm feeling nice today", "I'm gonna smack someone",
    "I'm good you good", "I'm grieved", "I'm impressed", "I'm in suspense", "I'm not dead yet",
    "I'm not sure", "I'm off today", "I'm on a roll", "I'm the boss", "I'm thrilled",
    "I'm tired of this", "IMHO", "I am not amused", "I be like", "I can't believe it",
    "I could be wrong", "I could swear", "I didn't do it", "I didn't see that", "I don't care",
    "I donno", "I forgot", "I give up", "I got your back", "I had a crazy dream",
    "I hate when that happens", "I have an idea", "I just might", "I love this", "I love you",
    "I made it that way", "I pity the fool", "I planned that", "I quit", "I see nothing",
    "I veto that", "I was just thinking", "I was sleeping", "Icarus", "If had my druthers",
    "Is that so", "Is that your final answer", "Isn't that special", "It's nice being God",
    "It grieves me", "Ivy league", "Japan", "Jedi mind trick", "Jesus", "King Midas",
    "Knock you upside the head", "LOL", "Make America Great Again", "Mars",
    "Mission Accomplished", "Mom", "Moses", "NOT", "NeilDeGrasseTyson", "Trump",
    "Oh Hell No", "Oh really", "Okilydokily", "One finger salute", "Oy", "Pope", "Putin",
    "Pullin the dragons tail", "ROFLMAO", "Russia", "Shakespeare", "Shalom", "Shhh",
    "StephenHawking", "SupremerCourt", "Kap", "That's gonna leave a mark", "That's my favorite",
    "The good stuff", "This is confusing", "Varoom", "Vegas", "Venus", "Watch this", "What",
    "What I want", "What are you doing Dave", "WooHoo", "Wow", "Yawn", "Yes you are", "Yo",
    "You can count on that", "You da man", "You fix it", "You get what you pray for", "You know",
    "Zap", "Zzzzzzzz", "a flag on that play", "a likely story", "a screw loose", "abnormal",
    "absetively posilutely", "absolutely", "act", "adjusted for inflation", "adultery",
    "after a break", "ahh", "ahh thats much better", "air head", "and the award goes to",
    "and then what", "angel", "anger", "application", "are you deaf", "are you feeling lucky",
    "are you insane", "are you sure", "arent you clever", "arrogant", "as a matter of fact",
    "astounding", "astronomical", "astrophysics", "atheist", "atrocious", "au revoir",
    "awesome", "awful", "ba ha", "bad", "bad ol puddytat", "baffling", "bank", "basically",
    "basket case", "bastard", "battle", "be happy", "be quiet bird", "beam me up",
    "because I said so", "beep beep", "begs the question", "bickering", "big fish", "biggot",
    "birds", "bizarre", "blessing", "boink", "boss", "break some woopass on you",
    "bring it on", "bummer", "busybody", "but of course", "by the way", "bye",
    "can you hear me now", "car", "catastrophe", "caution", "chaos", "charged", "charity",
    "check this out", "cheerful", "chess", "chill", "chill out", "choose one", "chump change",
    "church", "class  class  shutup", "clever", "climate", "close your eyes", "come and get me",
    "comedy", "commanded", "completely", "computers", "conservative", "cosmetics",
    "could it be   Satan", "couldn't be better", "couldnt possibly", "courage", "cowardice",
    "cracks me up", "crash and burn", "crazy", "cursing", "dance", "dang it", "Election", "Virus", "2025", "2026"
};
const int GOD_WORD_COUNT = sizeof(GOD_WORDS) / sizeof(GOD_WORDS[0]);

void to_upper(char *s) {
    for (; *s; ++s) {
        if (*s >= 'a' && *s <= 'z') {
            *s -= 32;
        }
    }
}

#define SCREEN_WIDTH 640
#define CHAR_WIDTH 8
#define LINE_HEIGHT 8

void god_speak(int amount, int y) {
    int x = 0;

    for (int i = 0; i < amount; i++) {
        int index = rand32() % GOD_WORD_COUNT;
        const char *word = GOD_WORDS[index];

        // Check if word fits, if not, wrap
        int word_len_px = 0;
        for (int j = 0; word[j]; j++) {
            word_len_px += CHAR_WIDTH;
        }

        if (x + word_len_px >= SCREEN_WIDTH) {
            x = 0;
            y += LINE_HEIGHT;
        }

        // Print word
        for (int j = 0; word[j]; j++) {
            putchar(word[j], x, y);
            x += CHAR_WIDTH;
        }

        // Add space, wrap if needed
        if (x + CHAR_WIDTH >= SCREEN_WIDTH) {
            x = 0;
            y += LINE_HEIGHT;
        } else {
            putchar(' ', x, y);
            x += CHAR_WIDTH;
        }
    }

    if (x + CHAR_WIDTH >= SCREEN_WIDTH) {
        x = 0;
        y += LINE_HEIGHT;
    }

    yP = y;

    putchar('.', x, y); // End with period
}

#define PIT_CHANNEL0    0x40
#define PIT_COMMAND     0x43
#define PIT_FREQUENCY   1193180

void pit_mode2_reload(uint16_t reload_value)
{
    outb(PIT_COMMAND, 0x34); // Channel 0, Access lo/hi, Mode 2, binary
    outb(PIT_CHANNEL0, reload_value & 0xFF);
    outb(PIT_CHANNEL0, (reload_value >> 8) & 0xFF);
}

void pit_delay_poll(uint16_t ticks)
{
    pit_mode2_reload(ticks);
    
    // Wait approximately for ticks * 0.838us
    for (volatile uint32_t i = 0; i < 50000; i++);
}

void delay(int ms)
{
    for (volatile uint32_t i = 0; i < ms * 30000; i++);
}

void test_pit_delay()
{
    putchar('S', 0, yP+8);
    delay(5000); // Delay 1 second
    putchar('E', 0, yP+16); // Should appear 1 second later
}

static void play_sound(uint32_t nFrequence)
{
 	uint32_t Div;
 	uint8_t tmp;

 	Div = 1193180 / nFrequence;
 	outb(0x43, 0xb6);
 	outb(0x42, (uint8_t) (Div) );
 	outb(0x42, (uint8_t) (Div >> 8));
 
 	tmp = inb(0x61);
  	if (tmp != (tmp | 3)) {
 		outb(0x61, tmp | 3);
 	}
}
 
static void nosound()
{
    uint8_t tmp = inb(0x61) & 0xFC;
    outb(0x61, tmp);
}

void beep()
{
    play_sound(1000);
    delay(10000);
    nosound();
}

void draw_big_fish(int y)
{
    const char *fish[] = {
        "     ><(((('>    ",
        "   ><(((('>      ",
        "><(((('>         ",
        "   ><(((('>      ",
        "     ><(((('>    "
    };

    const int fish_lines = sizeof(fish) / sizeof(fish[0]);

    for (int i = 0; i < fish_lines; i++) {
        const char *line = fish[i];
        int x = 0;
        for (int j = 0; line[j]; j++) {
            putchar(line[j], x, y + i * 8);
            x += CHAR_WIDTH;
        }
    }
}

int cursor_visible = 0;
const int CURSOR_WIDTH = 8;
const int CURSOR_HEIGHT = 8;
int doNotDrawCursor = 0;

void erase_cursor()
{
    fill_rect(xP, yP, CURSOR_WIDTH, CURSOR_HEIGHT, DEF_BG); // erase using background color
}

int appSelected = 0;
int sysSelected = 0;
int inBar = 0;

int dontAddToBuffer = 0;

typedef struct {
    uint32_t frequency; // in Hz
    uint32_t duration;  // in ms
} Note;

void play_note(uint32_t freq, uint32_t duration_ms) {
    if (freq > 0)
        play_sound(freq);
    delay(duration_ms * 10); // approximate, adjust if needed
    nosound();
    delay(10 * 2); // short pause between notes
}

void play_melody() {
    // Note melody[] = {
    //     {659, 300}, // E
    //     {587, 300}, // D
    //     {523, 300}, // C
    //     {587, 300}, // D
    //     {659, 300}, // E
    //     {659, 300}, // E
    //     {659, 600}, // E

    //     {587, 300}, // D
    //     {587, 300}, // D
    //     {587, 600}, // D

    //     {659, 300}, // E
    //     {784, 300}, // G
    //     {784, 600}, // G

    //     {659, 300}, // E
    //     {587, 300}, // D
    //     {523, 300}, // C
    //     {587, 300}, // D
    //     {659, 300}, // E
    //     {659, 300}, // E
    //     {659, 300}, // E
    //     {659, 300}, // E
    //     {587, 300}, // D
    //     {587, 300}, // D
    //     {659, 300}, // E
    //     {587, 300}, // D
    //     {523, 800}  // C
    // };

    Note melody[] = {
        {523, 400}, // C5
        {587, 400}, // D5
        {659, 400}, // E5
        {698, 400}, // F5
        {784, 600}, // G5
        {698, 400}, // F5
        {659, 400}, // E5
        {523, 800}  // C5
    };

    int note_count = sizeof(melody) / sizeof(Note);

    for (int i = 0; i < note_count; ++i) {
        play_note(melody[i].frequency, melody[i].duration);
    }
}

void poll_kbd_loop()
{
    for (int i = 0; i < GOD_WORD_COUNT; i++) {
        to_upper(GOD_WORDS[i]);
    }

    wait_for_entropy_and_seed();

    int blink_counter = 0;

    while(1)
    {
        dontAddToBuffer = 0;

        if (!doNotDrawCursor)
        {
            if (++blink_counter > 2000000) // crude timing loop
            {
                blink_counter = 0;
                cursor_visible = !cursor_visible;

                if (cursor_visible)
                    fill_rect(xP, yP, CURSOR_WIDTH, CURSOR_HEIGHT, 0);
                else
                    fill_rect(xP, yP, CURSOR_WIDTH, CURSOR_HEIGHT, DEF_BG);
            }
        }

        if (!keyboard_has_data()) continue;

        uint8_t scan = keyboard_read_scan_code();

        if (scan & 0x80)
        {
        }
        else
        {
            if (scan == 0x48)
            {
                doNotDrawCursor = 1;
                print_bg("APPS", 0, 0, DEF_BARSELECT);
                print_bg("SYSTEM", 56, 0, DEF_BAR);
                appSelected = 1;
                sysSelected = 0;
                inBar = 1;
                dontAddToBuffer = 1;
            }

            if (scan == 0x50)
            {
                doNotDrawCursor = 0;
                print_bg("APPS", 0, 0, DEF_BAR);
                print_bg("SYSTEM", 56, 0, DEF_BAR);
                appSelected = 0;
                sysSelected = 0;
                inBar = 0;
                dontAddToBuffer = 1;
            }

            if (scan == 0x4D)
            {
                if (inBar)
                {
                    sysSelected = 1;
                    appSelected = 0;
                    print_bg("APPS", 0, 0, DEF_BAR);
                    print_bg("SYSTEM", 56, 0, DEF_BARSELECT);
                }

                dontAddToBuffer = 1;
            }

            if (scan == 0x4B)
            {
                if (inBar)
                {
                    appSelected = 1;
                    sysSelected = 0;
                    print_bg("APPS", 0, 0, DEF_BARSELECT);
                    print_bg("SYSTEM", 56, 0, DEF_BAR);
                }

                dontAddToBuffer = 1;
            }

            scan &= 0x7F;

            erase_cursor();

            char c = scancode_to_ascii(scan);

            if (c == '\b')  // Handle backspace
            {
                if (input_len > 0)
                {
                    input_len--;
                    xP -= 8;
                    putchar(' ', xP, yP); // Clear char visually
                }
            }
            else if (c == '\n')  // Enter key pressed
            {
                if (inBar)
                {
                    if (appSelected)
                    {
                        print("GOD IS GOOD AND HE IS GREAT, BELIEVE IN HIM.", 0, yP);
                        yP += 8;
                    }
                    if (sysSelected)
                    {
                        print("BELIEVE IN GOD WITH ALL THY HEART.", 0, yP);
                        yP += 8;
                    }

                    dontAddToBuffer = 1;
                }
                else
                {
                    input_buffer[input_len] = '\0'; // Null-terminate

                    xP = 0;
                    yP += 8;

                    if (!strcmp(input_buffer, "GOD"))
                    {
                        print("GOD SAYS...", 0, yP);
                        god_speak(32, yP + 8);
                        play_melody();
                    }
                    if (!strcmp(input_buffer, "BEEP"))
                    {
                        beep();
                    }
                    if (!strcmp(input_buffer, "BIG.FISH"))
                    {
                        draw_big_fish(yP+8);
                        yP += 32;
                    }
                    if (!strcmp(input_buffer, "HELP"))
                    {
                        print("COMMAND LIST:", 0, yP);
                        print("GOD          : SPEAK TO GOD", 0, yP+8);
                        print("BEEP         : PLAY PC SPEAKER BEEP", 0, yP+16);
                        print("BIG.FISH     : SEE A BIG FISH", 0, yP+24);
                        print("SING         : PLAY A MELODY", 0, yP+32);

                        yP += 32;
                    }
                    if (!strcmp(input_buffer, "SING"))
                    {
                        play_melody();
                    }

                    // Reset buffer for next input
                    input_len = 0;
                    xP = 0;
                    yP += 16;
                }
            }
            else if (input_len < MAX_INPUT_LEN - 1)
            {
                if (!dontAddToBuffer)
                {
                    input_buffer[input_len++] = c;

                    // Draw character
                    putchar(c, xP, yP);
                    xP += 8;
                }
            }
        }
    }
}