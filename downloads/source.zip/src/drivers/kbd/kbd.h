#ifndef KBD_H
#define KBD_H

#include <stdint.h>
#include "../../kerneldef.h"
#include "../vga/vga.h"
#include "../../libc/stdio.h"

#define KBD_DATA 0x60
#define KBD_STATUS 0x64

void poll_kbd_loop();

#endif