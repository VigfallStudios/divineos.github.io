/* MY PURPOSE IS TO GLORIFY GOD THROUGH CODE.
   LORD, SPEAK TO ME THROUGH THE SYSTEM I AM BUILDING.
   USE ME AS YOUR SERVANT. */

#include "kerneldef.h"
#include "drivers/kbd/kbd.h"
#include "drivers/vga/vga.h"
#include "libc/stdio.h"
#include "drivers/disk/ata.h"
#include "wm/wm.h"

void dummy_test_entrypoint() {
    // dummy required by linker
}

const char* divine_verses[] = {
    "IN THE BEGINNING GOD CREATED THE HEAVEN AND THE EARTH.",
    "LET THERE BE LIGHT: AND THERE WAS LIGHT.",
    "I AM THE ALPHA AND THE OMEGA, THE BEGINNING AND THE END.",
    "BE STRONG AND COURAGEOUS. DO NOT BE AFRAID.",
    "THE LORD IS MY SHEPHERD; I SHALL NOT WANT.",
    "WITH GOD ALL THINGS ARE POSSIBLE.",
    "IN HIM WAS LIFE; AND THE LIFE WAS THE LIGHT OF MEN.",
    "FOR I KNOW THE PLANS I HAVE FOR YOU, SAITH THE LORD.",
    "BLESSED ARE THE PURE IN HEART: FOR THEY SHALL SEE GOD.",
    "THOU SHALT LOVE THE LORD THY GOD WITH ALL THY HEART.",
    "THE LIGHT SHINETH IN DARKNESS; AND THE DARKNESS COMPREHENDED IT NOT.",
    "I WILL NEVER LEAVE THEE, NOR FORSAKE THEE.",
    "THE HEAVENS DECLARE THE GLORY OF GOD.",
    "BE STILL, AND KNOW THAT I AM GOD.",
    "TRUST IN THE LORD WITH ALL THINE HEART.",
};

uint8_t cmos_read(uint8_t reg) {
    outb(0x70, reg);
    return inb(0x71);
}

const char* ask_god() {
    // Print a random bible phrase on boot
    uint8_t raw_seconds = cmos_read(0x00);
    uint8_t seconds = bcd_to_bin(raw_seconds);  // convert from BCD!
    serial_print_uint8(seconds);
    return divine_verses[seconds % (sizeof(divine_verses) / sizeof(char*))];
}

int disk_read_sector(int lba, int total, void* buf)
{
    uint16_t* ptr = (uint16_t*) buf;

    for (int b = 0; b < total; b++) {
        outb(0x1F6, ((lba + b) >> 24) | 0xE0);
        outb(0x1F2, 1);
        outb(0x1F3, (uint8_t)((lba + b) & 0xFF));
        outb(0x1F4, (uint8_t)((lba + b) >> 8));
        outb(0x1F5, (uint8_t)((lba + b) >> 16));
        outb(0x1F7, 0x20);

        // Wait until DRQ set
        char c = insb(0x1F7);
        while (!(c & 0x08)) {
            c = insb(0x1F7);
        }

        for (int i = 0; i < 256; i++) {
            *ptr++ = insw(0x1F0);
        }
    }

    return 0;
}

int disk_write_sector(int lba, int total, const void* buf)
{
    const uint16_t* ptr = (const uint16_t*) buf;

    for (int b = 0; b < total; b++) {
        outb(0x1F6, ((lba + b) >> 24) | 0xE0);
        outb(0x1F2, 1);
        outb(0x1F3, (uint8_t)((lba + b) & 0xFF));
        outb(0x1F4, (uint8_t)((lba + b) >> 8));
        outb(0x1F5, (uint8_t)((lba + b) >> 16));
        outb(0x1F7, 0x30);

        // Wait until DRQ set
        char c = insb(0x1F7);
        while (!(c & 0x08)) {
            c = insb(0x1F7);
        }

        for (int i = 0; i < 256; i++) {
            outw(0x1F0, *ptr++);
        }
    }

    return 0;
}

#define MAX_FILES 15
#define FILENAME_LEN 16

typedef struct {
    char name[FILENAME_LEN];  // Null-terminated
    uint32_t lba;
    uint32_t num_sectors;
} divine_file_entry_t;

int divinefs_write_file(const char* name, const void* data, uint32_t num_sectors) {
    uint8_t raw_sector[512] = {0};
    divine_file_entry_t* table = (divine_file_entry_t*) raw_sector;
    disk_read_sector(0, 1, table);

    // Find empty slot
    int free_slot = -1;
    for (int i = 0; i < MAX_FILES; i++) {
        if (table[i].name[0] == '\0') {
            free_slot = i;
            break;
        }
    }

    if (free_slot == -1) return -1;

    // Find next free LBA
    uint32_t next_lba = 2;
    for (int i = 0; i < MAX_FILES; i++) {
        if (table[i].name[0]) {
            uint32_t end = table[i].lba + table[i].num_sectors;
            if (end > next_lba) next_lba = end;
        }
    }

    // Save file data
    disk_write_sector(next_lba, num_sectors, data);

    // Update file table
    divine_file_entry_t* entry = &table[free_slot];
    strncpy(entry->name, name, FILENAME_LEN - 1);
    entry->name[FILENAME_LEN - 1] = '\0';
    entry->lba = next_lba;
    entry->num_sectors = num_sectors;

    disk_write_sector(0, 1, table);
    return 0;
}

int divinefs_read_file(const char* name, void* out_buf, uint32_t max_sectors) {
    uint8_t raw_sector[512] = {0};
    divine_file_entry_t* table = (divine_file_entry_t*) raw_sector;
    disk_read_sector(0, 1, table);

    for (int i = 0; i < MAX_FILES; i++) {
        if (strncmp(table[i].name, name, FILENAME_LEN) == 0) {
            if (table[i].num_sectors > max_sectors) return -2;
            disk_read_sector(table[i].lba, table[i].num_sectors, out_buf);
            return table[i].num_sectors;
        }
    }

    return -1; // not found
}

void write_install()
{
    // Install The Holy Divine Intellect Operating System
    char message[512] = "IN THE BEGINNING WAS THE WORD, AND THE WORD WAS WITH GOD, AND THE WORD WAS GOD.";
    print("WRITING...", 0, 80);
    divinefs_write_file("divine.txt", message, 1);
    print("DONE WRITE", 0, 100);
}

void read_boot_config()
{
    char readback[512] = {0};
    if (divinefs_read_file("divine.txt", readback, 1) > 0) {
        print("READ:", 0, 40);
        print(readback, 0, 60);
    } else {
        print("READ FAILED", 0, 40);
    }
}

void main()
{
    set_mode12h_palette();

    clear_screen();
    serial_init();

    fill_rect(0, 0, 640, 480, DEF_BG);

    // Draw content bar
    fill_rect(0, 0, 640, 10, DEF_BAR);
    print_bg("APPS", 0, 0, DEF_BAR);
    print_bg("SYSTEM", 56, 0, DEF_BAR);

    print("DIVINE INTELLECT OPERATING SYSTEM", 0, 10);

    const char *stir = ask_god();
    print(stir, 0, 20); 

    print("IN THE BEGINNING WAS THE WORD, AND THE WORD WAS WITH GOD, AND THE WORD WAS GOD.", 0, 460);

    poll_kbd_loop();
}