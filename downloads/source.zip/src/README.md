# The Divine Intellect Operating System
DIOS / Divine Intellect Operating System is an operating system directed by God himself, Inspired partly by TempleOS and Terry A. Davis (may he rest in peace).
