#ifndef STDIO_H
#define STDIO_H

#include <stdint.h>
#include "../drivers/vga/vga.h"

#define COM1_PORT 0x3F8

char* strcpy(char* dest, const char* src);
int strcmp(const char* a, const char* b);
void serial_init();
int serial_is_transmit_ready();
void serial_write_char(char c);
void serial_write_string(const char* str);
uint8_t bcd_to_bin(uint8_t bcd);
void serial_print_uint8(uint8_t num);
void putchar(char c, int x, int y);

#endif