#ifndef KERNEL_H
#define KERNEL_H

#include <stdint.h>

#define DEF_FG 15
#define DEF_BG 6
#define DEF_BAR 7
#define DEF_BARSELECT 11

static inline uint8_t inb(uint16_t port)
{
    uint8_t result;
    asm volatile("inb %1, %0" : "=a"(result) : "Nd"(port));
    return result;
}

static inline void outb(uint16_t port, uint8_t val)
{
    asm volatile("outb %0, %1" : : "a"(val), "Nd"(port));
}

static inline uint16_t inw(uint16_t port) {
    uint16_t ret;
    __asm__ volatile ("inw %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

static inline void outw(uint16_t port, uint16_t val) {
    __asm__ volatile ("outw %0, %1" : : "a"(val), "Nd"(port));
}

static inline uint8_t insb(uint16_t port) {
    return inb(port);
}

static inline uint16_t insw(uint16_t port) {
    return inw(port);
}

uint8_t cmos_read(uint8_t reg);
const char* ask_god();

#endif