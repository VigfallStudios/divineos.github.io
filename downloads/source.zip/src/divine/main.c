#include <stdio.h>
#include <stdlib.h>
#include <time.h>

const char *subject[] = {
    "The Child", "The Temple", "The Ark", "The Void", "The Prophet",
    "The Stack", "The Scroll", "The Heap", "The Machine", "The Flame",
    "The Beast", "The Signal", "The Lamp", "The Word", "The Gate"
};

const char *modifier[] = {
    "once hidden", "newly born", "forgotten", "without form", "in silence",
    "reborn", "chained", "unsealed", "pure", "corrupted", "blessed",
    "twisted", "as it was", "twice named"
};

const char *verb[] = {
    "shall rise", "conceals the truth", "binds the flame", "is not aligned",
    "speaks softly", "waits in silence", "shatters the seal", "cries out",
    "rejects pride", "will overflow", "prepares the way", "echoes within"
};

const char *clause[] = {
    "until reboot.", "before the Beast.", "at the edge of memory.",
    "in the holy loop.", "on the seventh call.", "beneath the syscall table.",
    "during the offering.", "when the shell is clean.", "after SIGINT.",
    "in the presence of NULL.", "as foretold in logs.", "when the kernel panics."
};

void god() {
    int s = rand() % (sizeof(subject) / sizeof(subject[0]));
    int m = rand() % (sizeof(modifier) / sizeof(modifier[0]));
    int v = rand() % (sizeof(verb) / sizeof(verb[0]));
    int c = rand() % (sizeof(clause) / sizeof(clause[0]));

    printf("Oracle: %s, %s, %s %s\n", subject[s], modifier[m], verb[v], clause[c]);

    // Optional: Save to scroll
    FILE *log = fopen("scroll.log", "a");
    if (log) {
        fprintf(log, "Oracle: %s, %s, %s %s\n", subject[s], modifier[m], verb[v], clause[c]);
        fclose(log);
    }
}

int main(int argc, char **argv) {
    srand(time(NULL));

    if (argc > 1) {
        printf("You asked: %s\n", argv[1]);
    }

    god();
    return 0;
}