#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

#define SECTOR_SIZE 512
#define MAX_FILES 15
#define FILENAME_LEN 16

typedef struct {
    char name[FILENAME_LEN];   // 16 bytes
    uint32_t lba;              // 4 bytes
    uint32_t num_sectors;      // 4 bytes
} divine_file_entry_t;

void extract_files(const char* image_path) {
    FILE* img = fopen(image_path, "rb");
    if (!img) {
        perror("Could not open image");
        return;
    }

    // Read file table from sector 0
    uint8_t sector[SECTOR_SIZE];
    fread(sector, 1, SECTOR_SIZE, img);

    divine_file_entry_t* table = (divine_file_entry_t*) sector;

    for (int i = 0; i < MAX_FILES; i++) {
        if (table[i].name[0] == '\0') continue;

        printf("[+] Extracting file: %s\n", table[i].name);

        uint32_t offset = table[i].lba * SECTOR_SIZE;
        uint32_t size = table[i].num_sectors * SECTOR_SIZE;

        // Allocate buffer for file content
        uint8_t* buffer = malloc(size);
        if (!buffer) {
            fprintf(stderr, "Memory error\n");
            continue;
        }

        fseek(img, offset, SEEK_SET);
        fread(buffer, 1, size, img);

        // Write to output file
        FILE* out = fopen(table[i].name, "wb");
        if (!out) {
            perror("Failed to create output file");
            free(buffer);
            continue;
        }

        fwrite(buffer, 1, size, out);
        fclose(out);
        free(buffer);

        printf("    %u bytes written.\n", size);
    }

    fclose(img);
}

int main(int argc, char** argv) {
    if (argc != 2) {
        printf("Usage: %s hdd.img\n", argv[0]);
        return 1;
    }

    extract_files(argv[1]);
    return 0;
}